export { default as env } from './env';
export type { EnvironmentConfig } from './env';