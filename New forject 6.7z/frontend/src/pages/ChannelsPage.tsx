import { ChannelList } from '../components'

function ChannelsPage() {
  return (
    <div className="channels-page">
      <ChannelList />
    </div>
  )
}

export default ChannelsPage